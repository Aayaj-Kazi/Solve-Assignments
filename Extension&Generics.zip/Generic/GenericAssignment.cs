﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Generic
{
    class GenericAssignment<T>
    {//convert String to number and string to date
        public T str { get; set; }

    }

   
}
